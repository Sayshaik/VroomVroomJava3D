import java.io.File;
import java.util.List;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.jogamp.java3d.Clip;

import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

public class crashDetector {
    private static CrashPopup crashPopup;
    private static boolean gameActive = true;
    
    private static javax.sound.sampled.Clip crashSoundClip;

    
    public static void initialize(JFrame parentFrame) {
        crashPopup = new CrashPopup(parentFrame);
        loadCrashSound();

    }
    
    public static void updateScore(int score) {
        if (crashPopup != null) {
            crashPopup.updateScore(score);
        }
    }
    
    private static void loadCrashSound() {
        try {
            // Load the crash sound file (assuming crash.wav is in the project directory)
            File soundFile = new File("sounds/crash.wav");
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundFile);
            crashSoundClip = AudioSystem.getClip();
            crashSoundClip.open(audioStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static boolean checkCollision(TransformGroup playerTG, List<carEnemy> enemies) {
        if (!gameActive) return false;
        
        Transform3D playerTransform = new Transform3D();
        playerTG.getTransform(playerTransform);
        Vector3f playerPos = new Vector3f();
        playerTransform.get(playerPos);
        
        float playerWidth = 1f;
        float playerHeight = 1f;
        float playerLength = 3f;
        
        for (carEnemy enemy : enemies) {
            Transform3D enemyTransform = new Transform3D();
            enemy.getTransformGroup().getTransform(enemyTransform);
            Vector3f enemyPos = new Vector3f();
            enemyTransform.get(enemyPos);
            
            float enemyWidth = 1f;
            float enemyHeight = 1f;
            float enemyLength = 3f;
            
            if (checkAABBCollision(
                playerPos.x, playerPos.y, playerPos.z, 
                playerWidth, playerHeight, playerLength,
                enemyPos.x, enemyPos.y, enemyPos.z,
                enemyWidth, enemyHeight, enemyLength)) {
           	 	playCrashSound(playerPos);

                
                gameActive = false;
                SwingUtilities.invokeLater(() -> {
                    crashPopup.showCrashPopup();
                });
                return true;
            }
        }
        return false;
    }
    
    public static void setGameActive(boolean active) {
        gameActive = active;
    }
    
    private static boolean checkAABBCollision(
        float x1, float y1, float z1, float w1, float h1, float l1,
        float x2, float y2, float z2, float w2, float h2, float l2) {
       
        boolean xOverlap = Math.abs(x1 - x2) * 2 < (w1 + w2);
        boolean yOverlap = Math.abs(y1 - y2) * 2 < (h1 + h2);
        boolean zOverlap = Math.abs(z1 - z2) * 2 < (l1 + l2);
        
        return xOverlap && yOverlap && zOverlap;
    }
    private static void playCrashSound(Vector3f playerPos) {
        if (crashSoundClip != null) {
            // Spatialize the sound (this is just a basic implementation)
            // You can use the playerPos for positioning the sound in a 3D environment
            System.out.println("Playing crash sound at position: " + playerPos);
            
            crashSoundClip.setFramePosition(0);  // Rewind the sound to the beginning
            crashSoundClip.start();              // Play the sound
        }
    }
}