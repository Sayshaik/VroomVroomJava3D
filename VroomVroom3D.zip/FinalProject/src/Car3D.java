import org.jogamp.java3d.*;
import org.jogamp.java3d.loaders.*;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.*;

import java.io.File;
import java.util.Scanner;

public class Car3D {
    private TransformGroup carTG;
    private BranchGroup carBodyBG;
    
    private static final String CAR_BODY_OBJ = "models/Car_Low_Polyy.obj";
    
    // Material properties
    private Material carBodyMaterial;
    private Texture carBodyTexture;
    
    public Car3D() {
        // Create main car transform group
        carTG = new TransformGroup();
        carTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        
        // Load textures and materials
        loadMaterials();
        
        // Load car body
        loadCarBody();
        
        // Set up collision bounds
        setCollisionBounds();
    }
    
    private void loadMaterials() {
        // Load car body material
        MTLFile carBodyMTL = new MTLFile(CAR_BODY_OBJ, 0);
        carBodyMaterial = createMaterial(carBodyMTL);
        carBodyTexture = carBodyMTL.texture;
    }
    
    private Material createMaterial(MTLFile mtl) {
        Material material = new Material();
        material.setAmbientColor(mtl.ambient);
        material.setDiffuseColor(mtl.diffuse);
        material.setSpecularColor(mtl.specular);
        material.setEmissiveColor(mtl.emissive);
        material.setShininess(mtl.shininess);
        material.setLightingEnable(true);
        return material;
    }
    
    private Appearance createAppearance(Material material, Texture texture) {
        Appearance appearance = new Appearance();
        appearance.setMaterial(material);
        
        if (texture != null) {
            TextureAttributes texAttr = new TextureAttributes();
            texAttr.setTextureMode(TextureAttributes.MODULATE);
            appearance.setTexture(texture);
            appearance.setTextureAttributes(texAttr);
        }
        
        return appearance;
    }
    
    private void loadCarBody() {
        try {
            // Load car body model
            ObjectFile objFile = new ObjectFile(ObjectFile.RESIZE);
            Scene carScene = objFile.load(CAR_BODY_OBJ);
            carBodyBG = carScene.getSceneGroup();
            
            // Apply appearance to all shapes in the car body
            setAppearanceToAllShapes(carBodyBG, createAppearance(carBodyMaterial, carBodyTexture));
            
            // Apply transformations
            Transform3D bodyTransform = new Transform3D();
            bodyTransform.setScale(0.1);
            bodyTransform.rotY(Math.PI); // Rotate if needed
            
            TransformGroup bodyTG = new TransformGroup(bodyTransform);
            bodyTG.addChild(carBodyBG);
            carTG.addChild(bodyTG);
            
        } catch (Exception e) {
            System.err.println("Error loading car body: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void setAppearanceToAllShapes(Node node, Appearance appearance) {
        if (node instanceof Shape3D) {
            ((Shape3D)node).setAppearance(appearance);
        } else if (node instanceof Group) {
            Group group = (Group)node;
            for (int i = 0; i < group.numChildren(); i++) {
                Node child = group.getChild(i);
                setAppearanceToAllShapes(child, appearance);
            }
        }
    }
    
    private void setCollisionBounds() {
        BoundingBox bounds = new BoundingBox(
            new Point3d(-1.5, -0.5, -2.5),
            new Point3d(1.5, 1.5, 2.5)
        );
        carTG.setCollisionBounds(bounds);
        carTG.setCapability(Group.ENABLE_COLLISION_REPORTING);
    }
    
    public TransformGroup getCarTG() {
        return carTG;
    }
    
    public void setPosition(float x, float y, float z) {
        Transform3D position = new Transform3D();
        position.setTranslation(new Vector3f(x, y, z));
        carTG.setTransform(position);
    }

    // MTL file loader class
    private class MTLFile {
        public float shininess = 0;
        public Color3f ambient = new Color3f();
        public Color3f diffuse = new Color3f();
        public Color3f specular = new Color3f();
        public Color3f emissive = new Color3f();
        public Texture texture = null;
        
        public MTLFile(String fileName, int mtlNum) {
            File mtlFile = new File(fileName.substring(0, fileName.length()-3)+"mtl");
            File objFile = new File(fileName.substring(0, fileName.length()-3)+"obj");
            Scanner sc = null;
            String mtlName = "";
            
            try { 
                sc = new Scanner(objFile); 
                while(mtlNum >= 0) {
                    String line = sc.nextLine();
                    if(line.startsWith("usemtl")) {
                        mtlNum--;
                        if(mtlNum < 0) {
                            mtlName = line.split("\\s+")[1];
                        }
                    }
                }
                sc.close();

                sc = new Scanner(mtlFile);
                while(sc.hasNext()) {
                    String line = sc.nextLine().trim();
                    if(line.startsWith("newmtl " + mtlName)) {
                        // Found our material, now parse its properties
                        while(sc.hasNext()) {
                            line = sc.nextLine().trim();
                            if(line.isEmpty()) continue;
                            if(line.startsWith("newmtl")) break;
                            
                            String[] parts = line.split("\\s+");
                            switch(parts[0]) {
                                case "Ns": 
                                    shininess = Float.parseFloat(parts[1]); 
                                    break;
                                case "Ka": 
                                    ambient = new Color3f(
                                        Float.parseFloat(parts[1]),
                                        Float.parseFloat(parts[2]),
                                        Float.parseFloat(parts[3]));
                                    break;
                                case "Kd": 
                                    diffuse = new Color3f(
                                        Float.parseFloat(parts[1]),
                                        Float.parseFloat(parts[2]),
                                        Float.parseFloat(parts[3]));
                                    break;
                                case "Ks": 
                                    specular = new Color3f(
                                        Float.parseFloat(parts[1]),
                                        Float.parseFloat(parts[2]),
                                        Float.parseFloat(parts[3]));
                                    break;
                                case "Ke": 
                                    emissive = new Color3f(
                                        Float.parseFloat(parts[1]),
                                        Float.parseFloat(parts[2]),
                                        Float.parseFloat(parts[3]));
                                    break;
                                case "map_Kd": 
                                    texture = getTexture(parts[1]);
                                    break;
                            }
                        }
                        break;
                    }
                }
            } catch (Exception e) { 
                e.printStackTrace();
            } finally {
                if(sc != null) sc.close();
            }
        }
        
        private Texture getTexture(String fileName) {
            try {
                TextureLoader loader = new TextureLoader("models/"+fileName, null);
                ImageComponent2D image = loader.getImage();
                if(image == null) {
                    System.err.println("Failed to load texture: models/" + fileName);
                    return null;
                }
                Texture2D texture = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());
                texture.setImage(0, image);
                return texture;
            } catch (Exception e) {
                System.err.println("Error loading texture: " + e.getMessage());
                return null;
            }
        }
    }
}