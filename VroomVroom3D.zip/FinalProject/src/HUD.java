import org.jogamp.java3d.*;
import org.jogamp.vecmath.Point3f;
import org.jogamp.vecmath.Vector3f;
import java.awt.Font;

public class HUD {
    private BranchGroup scoreBranchGroup;
    private BranchGroup timerBranchGroup;

    private int score;
    private int time;

    public HUD() {
        score = 0;
        time = 0;

        // Create the score and timer labels in 3D
        scoreBranchGroup = createTextNode("Score: " + score, new Point3f(-12f, 14.5f, 0.0f));
        timerBranchGroup = createTextNode("Time: " + time, new Point3f(-12f, 15.5f, 0.0f));
    }

    private BranchGroup createTextNode(String text, Point3f position) {
        Font3D font3D = new Font3D(new Font("Arial", Font.PLAIN, 1), new FontExtrusion());
        Text3D text3D = new Text3D(font3D, text, new Point3f(0.0f, 0.0f, 0.0f));
        text3D.setCapability(Text3D.ALLOW_STRING_WRITE);

        Appearance appearance = new Appearance();
        Material material = new Material();
        material.setDiffuseColor(0.0f, 0.0f, 0.0f); // Black text
        appearance.setMaterial(material);

        Transform3D scaleTransform = new Transform3D();
        scaleTransform.setScale(0.3); // Adjust scale if needed

        Transform3D positionTransform = new Transform3D();
        positionTransform.setTranslation(new Vector3f(position));

        scaleTransform.mul(positionTransform);

        TransformGroup transformGroup = new TransformGroup(scaleTransform);
        Shape3D shape3D = new Shape3D(text3D, appearance);
        transformGroup.addChild(shape3D);

        BranchGroup branchGroup = new BranchGroup();
        branchGroup.addChild(transformGroup);

        return branchGroup;
    }

    public void updateScore(int newScore) {
        score = newScore;
        updateText(scoreBranchGroup, "Score: " + score);
    }

    public void updateTime(int newTime) {
        time = newTime;
        updateText(timerBranchGroup, "Time: " + time);
    }

    private void updateText(BranchGroup bg, String text) {
        TransformGroup tg = (TransformGroup) bg.getChild(0);
        Shape3D shape3D = (Shape3D) tg.getChild(0);
        Text3D text3D = (Text3D) shape3D.getGeometry();
        text3D.setString(text);
    }

    public BranchGroup getScoreBranchGroup() {
        return scoreBranchGroup;
    }

    public BranchGroup getTimerBranchGroup() {
        return timerBranchGroup;
    }
}