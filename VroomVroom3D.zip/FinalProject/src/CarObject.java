/*import org.jogamp.java3d.*;
import org.jogamp.java3d.loaders.IncorrectFormatException;
import org.jogamp.java3d.loaders.ParsingErrorException;
import org.jogamp.java3d.loaders.Scene;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.vecmath.*;
import java.io.FileNotFoundException;

public abstract class CarObject {
    protected TransformGroup objTG;
    protected BranchGroup objBG;
    protected double scale;
    protected Vector3f position;
    protected Shape3D objShape;
    protected Appearance app = new Appearance();

    public abstract TransformGroup positionObject();

    protected Scene loadShape(String obj_name) {
        ObjectFile f = new ObjectFile(ObjectFile.RESIZE, (float) (60 * Math.PI / 180.0));
        Scene s = null;
        try {                                                // load object's definition file to 's'
            s = f.load("models/" + obj_name + ".obj");
        } catch (FileNotFoundException e) {
            System.err.println(e);
            System.exit(1);
        } catch (ParsingErrorException e) {
            System.err.println(e);
            System.exit(1);
        } catch (IncorrectFormatException e) {
            System.err.println(e);
            System.exit(1);
        }
        return s;                                            // return the object shape in 's'
    }

    protected void transformObject(String objName) {
        Transform3D transform = new Transform3D();
        transform.setScale(scale);
        transform.setTranslation(position);
        objTG = new TransformGroup(transform);
        objBG = loadShape(objName).getSceneGroup();
        objShape = (Shape3D) objBG.getChild(0);
        objShape.setName(objName);
    }
}

class CarFrontWheels extends CarObject {
    public CarFrontWheels() {
        scale = 0.5;
        position = new Vector3f(1.2f, -0.5f, 1.5f);
        transformObject("CarFrontWheels");
        objShape.setAppearance(app);
    }

    public TransformGroup positionObject() {
        TransformGroup rotationGroup = new TransformGroup();
        rotationGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        objTG.addChild(rotationGroup);
        rotationGroup.addChild(objBG);
        
        WheelRotation wheelRotation = new WheelRotation(rotationGroup, 800);
        rotationGroup.addChild(wheelRotation);
        
        return objTG;
    }
}

class CarBackWheels extends CarObject {
    public CarBackWheels() {
        scale = 0.5;
        position = new Vector3f(-1.2f, -0.5f, 1.5f);
        transformObject("CarBackWheels");
        objShape.setAppearance(app);
    }

    public TransformGroup positionObject() {
        TransformGroup rotationGroup = new TransformGroup();
        rotationGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        objTG.addChild(rotationGroup);
        rotationGroup.addChild(objBG);
        
        WheelRotation wheelRotation = new WheelRotation(rotationGroup, 800);
        rotationGroup.addChild(wheelRotation);
        
        return objTG;
    }
}

class WheelRotation extends RotationInterpolator {
    private Alpha alpha;

    public WheelRotation(TransformGroup targetTG, long duration) {
        super(new Alpha(-1, duration), targetTG, createRotationAxis(), 0.0f, (float) (-2 * Math.PI));
        this.alpha = (Alpha) this.getAlpha();
        this.setSchedulingBounds(new BoundingSphere(new Point3d(), 1000.0));
    }

    private static Transform3D createRotationAxis() {
        Transform3D axis = new Transform3D();
        axis.rotX(Math.PI / 2);  // Rotate wheels along the X-axis
        return axis;
    }
}*/
