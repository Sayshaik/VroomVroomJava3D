import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CrashPopup {
    private JFrame frame;
    private long startTime;
    private int score;
    
    public CrashPopup(JFrame parentFrame) {
        this.frame = parentFrame;
        this.startTime = System.currentTimeMillis();
    }
    
    public void updateScore(int newScore) {
        this.score = newScore;
    }
    
    public void showCrashPopup() {
        // Calculate play time
        long endTime = System.currentTimeMillis();
        long playTimeMillis = endTime - startTime;
        long seconds = (playTimeMillis / 1000) % 60;
        long minutes = (playTimeMillis / (1000 * 60)) % 60;
        String playTime = String.format("%02d:%02d", minutes, seconds);
        
        // Create the popup dialog
        JDialog crashDialog = new JDialog(frame, "Game Over", true);
        crashDialog.setLayout(new BorderLayout());
        crashDialog.setSize(300, 200);
        crashDialog.setLocationRelativeTo(frame);
        
        // Create content panel
        JPanel contentPanel = new JPanel(new GridLayout(3, 1));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Add game over message
        JLabel messageLabel = new JLabel("You Crashed! Game Over ", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 18));
        contentPanel.add(messageLabel);
        
        // Add stats
        JLabel statsLabel = new JLabel(
            "<html><center>" +
            "Time: " + playTime + "<br>" +
            "Score: " + score +
            "</center></html>", SwingConstants.CENTER);
        contentPanel.add(statsLabel);
        
        // Add play again button
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crashDialog.dispose();
                resetGame();
            }
        });
        contentPanel.add(playAgainButton);
        
        crashDialog.add(contentPanel, BorderLayout.CENTER);
        crashDialog.setVisible(true);
    }
    
    private void resetGame() {
        // Reset the timer for the new game
        startTime = System.currentTimeMillis();
        score = 0;
        
        // Reset the game state
        crashDetector.setGameActive(true);
        road.getInstance().resetGame();
    }
}