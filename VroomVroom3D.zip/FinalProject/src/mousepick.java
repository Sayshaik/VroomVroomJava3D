import javax.swing.*;
import java.awt.event.*;
import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.picking.*;
import org.jogamp.vecmath.*;

public class mousepick implements MouseListener {
    private PickTool pickTool;
    private BranchGroup sceneRoot;

    public mousepick(BranchGroup sceneBG) {
        sceneRoot = sceneBG;
        pickTool = new PickTool(sceneRoot);
        pickTool.setMode(PickTool.BOUNDS);
    }

    @Override
    public void mouseClicked(MouseEvent event) {
        int x = event.getX();
        int y = event.getY();

        Point3d point3d = new Point3d();
        Canvas3D canvas3D = (Canvas3D) event.getSource();
        canvas3D.getPixelLocationInImagePlate(x, y, point3d);

        Point3d center = new Point3d();
        canvas3D.getCenterEyeInImagePlate(center);

        Transform3D transform3D = new Transform3D();
        canvas3D.getImagePlateToVworld(transform3D);
        transform3D.transform(point3d);
        transform3D.transform(center);

        Vector3d mouseVec = new Vector3d();
        mouseVec.sub(point3d, center);
        mouseVec.normalize();

        pickTool.setShapeRay(point3d, mouseVec);
        PickResult pickResult = pickTool.pickClosest();

        if (pickResult == null) {
            road.speedBoost();
            return;
        }

        Node node = pickResult.getNode(PickResult.PRIMITIVE);
        if (node != null && node.getUserData() instanceof String && node.getUserData().equals("PowerUp")) {
            road.speedBoost();
        } else {
            road.speedBoost();
        }
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
}