import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

public class powerUp {

    private static final int STAR_POINTS = 5;
    private static final float DEPTH = 0.2f;  // Total depth of the object
    float alpha = 0.0f;
    float alphaIncrement = 0.01f;

    private Shape3D frontShape1;
    private Shape3D frontShape2;
    private Shape3D sideShape;
    private TransformGroup frontShape1TG;
    private TransformGroup frontShape2TG;
    private TransformGroup sideShapeTG;

    public powerUp() {}

    public Shape3D createFront(double radius, Color3f color, float zOffset) {
        // Create geometry points and morph them
        Point3f[] starPts = starPoints(zOffset, radius, radius * 0.4f);
        Point3f[] circlePts = circlePoints(zOffset, radius);
        Point3f[] morphPts = morphPoints(starPts, circlePts, alpha);

        // Geometry array
        TriangleFanArray geometry = new TriangleFanArray(
            morphPts.length + 2,
            GeometryArray.COORDINATES | GeometryArray.COLOR_3,
            new int[]{morphPts.length + 2}
        );

        geometry.setCapability(GeometryArray.ALLOW_COORDINATE_WRITE);
        geometry.setCoordinate(0, new Point3f(0, 0, zOffset));
        for (int i = 0; i < morphPts.length; i++) {
            geometry.setCoordinate(i + 1, morphPts[i]);
            geometry.setColor(i + 1, color);
        }
        geometry.setCoordinate(morphPts.length + 1, morphPts[0]);

        // Create Shape3D
        Shape3D frontShape = new Shape3D(geometry, createAppearance());
        frontShape.setCapability(Shape3D.ALLOW_GEOMETRY_READ);  // Allow geometry reading
        frontShape.setCapability(Shape3D.ALLOW_BOUNDS_READ);    // Allow bounds reading
        frontShape.setCapability(Shape3D.ENABLE_COLLISION_REPORTING);  // Enable collision reporting
        frontShape.setCollisionBounds(new BoundingBox(new Point3d(-radius, -radius, zOffset - 0.5), new Point3d(radius, radius, zOffset + 0.5))); // Define bounding box

        TransformGroup transformGroup = new TransformGroup();
        transformGroup.addChild(frontShape);

        if (zOffset > 0) {
            frontShape1 = frontShape;
            frontShape1TG = transformGroup;
        } else {
            frontShape2 = frontShape;
            frontShape2TG = transformGroup;
        }
        return frontShape;
    }


    public Shape3D createSide(double radius, Color3f color) {
        Point3f[] frontStarPts = starPoints(DEPTH / 2, radius, radius * 0.4f);
        Point3f[] frontCirclePts = circlePoints(DEPTH / 2, radius);
        Point3f[] frontMorphPts = morphPoints(frontStarPts, frontCirclePts, alpha);

        Point3f[] backStarPts = starPoints(-DEPTH / 2, radius, radius * 0.4f);
        Point3f[] backCirclePts = circlePoints(-DEPTH / 2, radius);
        Point3f[] backMorphPts = morphPoints(backStarPts, backCirclePts, alpha);

        QuadArray geometry = new QuadArray(
            frontMorphPts.length * 4,
            GeometryArray.COORDINATES | GeometryArray.COLOR_3
        );

        geometry.setCapability(GeometryArray.ALLOW_COORDINATE_WRITE);
        for (int i = 0; i < frontMorphPts.length; i++) {
            int next = (i + 1) % frontMorphPts.length;

            geometry.setCoordinate(i * 4, new Point3f(frontMorphPts[i].x, frontMorphPts[i].y, DEPTH / 2));
            geometry.setCoordinate(i * 4 + 1, new Point3f(frontMorphPts[next].x, frontMorphPts[next].y, DEPTH / 2));
            geometry.setCoordinate(i * 4 + 2, new Point3f(backMorphPts[next].x, backMorphPts[next].y, -DEPTH / 2));
            geometry.setCoordinate(i * 4 + 3, new Point3f(backMorphPts[i].x, backMorphPts[i].y, -DEPTH / 2));
        }

        sideShape = new Shape3D(geometry, createAppearance());
        sideShape.setCapability(Shape3D.ALLOW_GEOMETRY_READ);  // Allow geometry reading
        sideShape.setCapability(Shape3D.ALLOW_BOUNDS_READ);    // Allow bounds reading
        sideShape.setCapability(Shape3D.ENABLE_COLLISION_REPORTING); 
        sideShapeTG = new TransformGroup();
        sideShapeTG.addChild(sideShape);
        return sideShape;
    }

    // Generates star points
    static Point3f[] starPoints(float z, double outerR, double innerR) {
        Point3f[] points = new Point3f[STAR_POINTS * 2];
        double angleStep = Math.PI / STAR_POINTS;

        for (int i = 0; i < STAR_POINTS; i++) {
            double angle = angleStep * i * 2;
            points[i * 2] = new Point3f(
                (float) (Math.cos(angle) * outerR),
                (float) (Math.sin(angle) * outerR),
                z
            );
            points[i * 2 + 1] = new Point3f(
                (float) (Math.cos(angle + angleStep) * innerR),
                (float) (Math.sin(angle + angleStep) * innerR),
                z
            );
        }
        return points;
    }

   
    static Point3f[] circlePoints(float z, double r) {
        Point3f[] points = new Point3f[STAR_POINTS * 2];
        double angleStep = Math.PI / STAR_POINTS;

        for (int i = 0; i < STAR_POINTS * 2; i++) {
            double angle = angleStep * i;
            points[i] = new Point3f(
                (float) (Math.cos(angle) * r),
                (float) (Math.sin(angle) * r),
                z
            );
        }
        return points;
    }

  
    static Point3f[] morphPoints(Point3f[] shape1, Point3f[] shape2, float alpha) {
        Point3f[] points = new Point3f[shape1.length];
        for (int i = 0; i < shape1.length; i++) {
            points[i] = new Point3f(
                (1 - alpha) * shape1[i].x + alpha * shape2[i].x,
                (1 - alpha) * shape1[i].y + alpha * shape2[i].y,
                shape1[i].z
            );
        }
        return points;
    }

    private static Appearance createAppearance() {
        Appearance app = new Appearance();
        PolygonAttributes polyAttr = new PolygonAttributes();
        polyAttr.setCullFace(PolygonAttributes.CULL_NONE);
        app.setPolygonAttributes(polyAttr);
        return app;
    }

    public void update() {
        alpha += alphaIncrement;
        if (alpha >= 1.0f || alpha <= 0.0f) {
            alphaIncrement *= -1;
        }

        if (frontShape1 != null) {
            Point3f[] starPts = starPoints(DEPTH / 2, 1.0, 0.4f);
            Point3f[] circlePts = circlePoints(DEPTH / 2, 1.0);
            Point3f[] morphPts = morphPoints(starPts, circlePts, alpha);

            TriangleFanArray geometry = (TriangleFanArray) frontShape1.getGeometry();
            geometry.setCoordinate(0, new Point3f(0, 0, DEPTH / 2));
            for (int i = 0; i < morphPts.length; i++) {
                geometry.setCoordinate(i + 1, morphPts[i]);
            }
            geometry.setCoordinate(morphPts.length + 1, morphPts[0]);
        }

        if (frontShape2 != null) {
            Point3f[] starPts = starPoints(-DEPTH / 2, 1.0, 0.4f);
            Point3f[] circlePts = circlePoints(-DEPTH / 2, 1.0);
            Point3f[] morphPts = morphPoints(starPts, circlePts, alpha);

            TriangleFanArray geometry = (TriangleFanArray) frontShape2.getGeometry();
            geometry.setCoordinate(0, new Point3f(0, 0, -DEPTH / 2));
            for (int i = 0; i < morphPts.length; i++) {
                geometry.setCoordinate(i + 1, morphPts[i]);
            }
            geometry.setCoordinate(morphPts.length + 1, morphPts[0]);
        }

        if (sideShape != null) {
            Point3f[] frontStarPts = starPoints(DEPTH / 2, 1.0, 0.4f);
            Point3f[] frontCirclePts = circlePoints(DEPTH / 2, 1.0);
            Point3f[] frontMorphPts = morphPoints(frontStarPts, frontCirclePts, alpha);

            Point3f[] backStarPts = starPoints(-DEPTH / 2, 1.0, 0.4f);
            Point3f[] backCirclePts = circlePoints(-DEPTH / 2, 1.0);
            Point3f[] backMorphPts = morphPoints(backStarPts, backCirclePts, alpha);

            QuadArray geometry = (QuadArray) sideShape.getGeometry();

            for (int i = 0; i < frontMorphPts.length; i++) {
                int next = (i + 1) % frontMorphPts.length;
                geometry.setCoordinate(i * 4, new Point3f(frontMorphPts[i].x, frontMorphPts[i].y, DEPTH / 2));
                geometry.setCoordinate(i * 4 + 1, new Point3f(frontMorphPts[next].x, frontMorphPts[next].y, DEPTH / 2));
                geometry.setCoordinate(i * 4 + 2, new Point3f(backMorphPts[next].x, backMorphPts[next].y, -DEPTH / 2));
                geometry.setCoordinate(i * 4 + 3, new Point3f(backMorphPts[i].x, backMorphPts[i].y, -DEPTH / 2));
            }
        }
    }

    public TransformGroup createCompletePowerUp(double radius, Color3f color) {
       
        frontShape1 = createFront(radius, color, DEPTH / 2);
        frontShape2 = createFront(radius, color, -DEPTH / 2);
        sideShape = createSide(radius, color);

        TransformGroup powerUpTG = new TransformGroup();
        powerUpTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);

       
        Group completePowerUpGroup = new Group();
        completePowerUpGroup.addChild(frontShape1TG);
        completePowerUpGroup.addChild(frontShape2TG);
        completePowerUpGroup.addChild(sideShapeTG);

        powerUpTG.addChild(completePowerUpGroup);
        return powerUpTG;
    }
}