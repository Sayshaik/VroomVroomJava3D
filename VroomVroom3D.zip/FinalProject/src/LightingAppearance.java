import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

public class LightingAppearance {
    // Constants for lighting and material colors
    private static final Color3f RED = new Color3f(1.0f, 1.0f, 1.0f);
    private static final Color3f BLACK = new Color3f(0.0f, 0.0f, 0.0f);
    private static final Color3f GRAY = new Color3f(0.5f, 0.5f, 0.5f);

    /**
     * Adds ambient and directional lighting to the scene.
     *
     * @param root The root BranchGroup of the scene.
     */
    public static void addLighting(BranchGroup root) {
        // Ambient light (soft overall light)
        AmbientLight ambientLight = new AmbientLight(RED);
        ambientLight.setInfluencingBounds(new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0));
        root.addChild(ambientLight);

        // Directional light (simulates a light source like the sun)
        DirectionalLight directionalLight = new DirectionalLight(RED, new Vector3f(-1.0f, -1.0f, -1.0f));
        directionalLight.setInfluencingBounds(new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0));
        root.addChild(directionalLight);
    }

    /**
     * Creates a default appearance with a material.
     *
     * @return An Appearance object with a default material.
     */
    public static Appearance createDefaultAppearance() {
        Appearance appearance = new Appearance();

        // Create a material with some basic properties
        Material material = new Material();
        material.setAmbientColor(GRAY);  // Ambient color (under low light)
        material.setDiffuseColor(RED); // Diffuse color (main color under light)
        material.setSpecularColor(RED); // Specular color (highlight color)
        material.setShininess(64.0f);    // Shininess (how reflective the material is)
        material.setLightingEnable(true); // Enable lighting for this material

        appearance.setMaterial(material);
        return appearance;
    }

    /**
     * Adjusts the size of a model using a TransformGroup.
     *
     * @param model The TransformGroup representing the model.
     * @param scale The scaling factor (e.g., 1.0 for no scaling, 0.5 for half size, 2.0 for double size).
     * @return A TransformGroup containing the scaled model.
     */
    public static TransformGroup adjustModelSize(TransformGroup model, double scale) {
        TransformGroup scaleTG = new TransformGroup();
        Transform3D scaleTransform = new Transform3D();
        scaleTransform.setScale(new Vector3d(scale, scale, scale)); // Uniform scaling
        scaleTG.setTransform(scaleTransform);
        scaleTG.addChild(model); // Add the model to the scaling TransformGroup
        return scaleTG;
    }
}