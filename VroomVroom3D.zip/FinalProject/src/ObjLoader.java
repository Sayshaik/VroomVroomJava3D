import java.io.FileNotFoundException;

import org.jogamp.java3d.*;
import org.jogamp.java3d.loaders.*;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.java3d.utils.geometry.Box;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.*;

public abstract class ObjLoader{
	protected TransformGroup carTG;
    protected TransformGroup frontWheelsTG;
    protected TransformGroup backWheelsTG;
    

	protected Alpha rotationAlpha;                           // NOTE: keep for future use
    protected BranchGroup objBG;                             // load external object to 'objBG'
    protected TransformGroup objTG;                          // use 'objTG' to position an object
    protected TransformGroup objRG;                          // use 'objRG' to rotate an object
    protected double scale;                                  // use 'scale' to define scaling
    protected Vector3f post;    
    protected Shape3D obj_shape;// use 'post' to specify location
    
    //these abstract methods should be implemented by other classes
    public abstract TransformGroup position_Object();        // need to be defined in derived classes
    public abstract void add_Child(TransformGroup nextTG);
    
    protected void setAlpha(Alpha alpha) {
        this.rotationAlpha = alpha;   
}
    public Alpha get_Alpha() {
        return rotationAlpha;
    } 
    //loads and returns object shape from file 
    protected Scene loadShape(String obj_name) {
        ObjectFile f = new ObjectFile(ObjectFile.RESIZE, (float) (60 * Math.PI / 180.0));
        Scene s = null;
        try {                                                // load object's definition file to 's'
            s = f.load("models/" + obj_name + ".obj");
        } catch (FileNotFoundException e) {
            System.err.println(e);
            System.exit(1);
        } catch (ParsingErrorException e) {
            System.err.println(e);
            System.exit(1);
        } catch (IncorrectFormatException e) {
            System.err.println(e);
            System.exit(1);
        }
        return s;                                            // return the object shape in 's'
    }
    
    protected void transform_Object(String obj_name) {
        Transform3D scaler = new Transform3D();
        scaler.setScale(scale);                              // set scale for the 4x4 matrix
        scaler.setTranslation(post);                         // set translations for the 4x4 matrix
        objTG = new TransformGroup(scaler);                  // set the translation BG with the 4x4 matrix
        objBG = loadShape(obj_name).getSceneGroup();         // load external object to 'objBG'
        obj_shape = (Shape3D) objBG.getChild(0);             // get and cast the object to 'obj_shape'
        obj_shape.setName(obj_name);                         // use the name to identify the object
    }
    
    //change this later
    protected Appearance app = new Appearance();
    protected int shine = 32;                                // shininess level adjuster
    protected Color3f[] mtl_clr = {
            new Color3f(1.000000f, 1.000000f, 1.000000f), //white (ambient color)
            new Color3f(0.772500f, 0.654900f, 0.000000f), //gold like color (diffuse color)
            new Color3f(0.175000f, 0.175000f, 0.175000f), //dark grey (specular color)
            new Color3f(0.000000f, 0.000000f, 0.000000f) //black (emissive color)
    };
    
    protected void obj_Appearance() {
        // Create a fresh appearance for each object
        Appearance app = new Appearance();
        
        // Enable lighting but don't set material colors
        Material mtl = new Material();
        mtl.setLightingEnable(true);
        app.setMaterial(mtl);
        
        // Set polygon attributes for better rendering
        PolygonAttributes polyAttrs = new PolygonAttributes();
        polyAttrs.setCullFace(PolygonAttributes.CULL_NONE);
        app.setPolygonAttributes(polyAttrs);
        
        obj_shape.setAppearance(app);
    }

    protected Appearance loadTexture(String textureFile) {
        // Changed from "images/" to "textures/" to match your texture folder
        String filePath = "textures/" + textureFile;  
        System.out.println("Loading texture from: " + filePath);
        
        TextureLoader loader = new TextureLoader(filePath, null);
        ImageComponent2D image = loader.getImage();
        
        if (image == null) {
            System.err.println("Failed to load texture: " + filePath);
            return createDefaultAppearance();
        }

        Texture2D texture = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, 
                                        image.getWidth(), image.getHeight());
        texture.setImage(0, image);
        
        Appearance app = new Appearance();
        TextureAttributes texAttr = new TextureAttributes();
        texAttr.setTextureMode(TextureAttributes.MODULATE);
        app.setTexture(texture);
        app.setTextureAttributes(texAttr);

        return app;
    }
    private Appearance createDefaultAppearance() {
        Appearance app = new Appearance();
        app.setColoringAttributes(new ColoringAttributes(
            new Color3f(1,0,0), ColoringAttributes.FASTEST)); // Red for missing textures
        return app;
    }
    
    protected void applyTextureToObject(Shape3D objShape, String textureFile) {
        if (objShape == null) {
            System.err.println("Cannot apply texture - shape is null");
            return;
        }
        
        // Create new appearance for textured object
        Appearance texApp = new Appearance();
        
        // Load texture
        String filePath = "textures/" + textureFile;
        System.out.println("Loading texture from: " + filePath);
        
        TextureLoader loader = new TextureLoader(filePath, null);
        ImageComponent2D image = loader.getImage();
        
        if (image == null) {
            System.err.println("Failed to load texture: " + filePath);
            texApp.setColoringAttributes(new ColoringAttributes(
                new Color3f(1,0,0), ColoringAttributes.FASTEST)); // Red if missing
        } else {
            // Configure texture properly
            Texture2D texture = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, 
                                             image.getWidth(), image.getHeight());
            texture.setImage(0, image);
            texture.setBoundaryModeS(Texture.WRAP);
            texture.setBoundaryModeT(Texture.WRAP);
            texture.setMinFilter(Texture.BASE_LEVEL_LINEAR);
            texture.setMagFilter(Texture.BASE_LEVEL_LINEAR);
            
            // Set texture attributes
            TextureAttributes texAttr = new TextureAttributes();
            texAttr.setTextureMode(TextureAttributes.MODULATE);
            
            // Configure appearance
            texApp.setTexture(texture);
            texApp.setTextureAttributes(texAttr);
            
            // Enable lighting
            Material mtl = new Material();
            mtl.setLightingEnable(true);
            texApp.setMaterial(mtl);
        }
        
        objShape.setAppearance(texApp);
    }
public void setCollisionBounds(BoundingBox bounds) {
    if (obj_shape != null) {
        obj_shape.setCollisionBounds(bounds);
    }
}
}

class BowlingBall extends ObjLoader{
	public BowlingBall() {
		scale = 0.8;                                         // scale the object
        post = new Vector3f(0f, 0f, 0f);                     // position it at origin
        transform_Object("bowlingBall");                      // load the bowling ball model (make sure the model is in the correct directory)
          
        
        applyTextureToObject(obj_shape, "balltexture.jpg");

        
        obj_shape.setCapability(Shape3D.ALLOW_GEOMETRY_READ);
        obj_shape.setCapability(Shape3D.ALLOW_BOUNDS_READ);
        obj_shape.setCapability(Shape3D.ENABLE_COLLISION_REPORTING);    
	}
	public void setCapability(int capability) {
	    obj_shape.setCapability(capability);
	}
	
	public void setCollisionBounds(BoundingBox bounds) {
	    obj_shape.setCollisionBounds(bounds);
	}
	
	public TransformGroup position_Object() {
		Transform3D rotateAxis = new Transform3D();
	    rotateAxis.rotY(0.01);  // adjust speed of rotation (0.01 radians per frame)
	    objRG = new TransformGroup(rotateAxis);
	    objRG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);  // allow the transformation to be updated
	    objTG.addChild(objRG);
	    objRG.addChild(objBG);

	    // Create rotation using Alpha to manage smooth continuous animation
	    rotationAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE | Alpha.DECREASING_ENABLE, 0, 0, 5000, 5000, 200, 5000, 5000, shine);
	    RotationInterpolator rotationInterpolator = new RotationInterpolator(rotationAlpha, objRG);
	    rotationInterpolator.setSchedulingBounds(new BoundingSphere(new Point3d(), 1000.0)); // define a bounding sphere for animation scheduling
	    objRG.addChild(rotationInterpolator);

	    return objTG;
	}
	public void add_Child(TransformGroup nextTG) {
		if (objRG == null) {
			objRG = new TransformGroup();
		}
	    objRG.addChild(nextTG);                             
	    }
	public TransformGroup getTransformGroup() {
	    return objTG;
	}
	public Vector3f getPosition() {
	    Transform3D transform = new Transform3D();
	    objTG.getTransform(transform);
	    Vector3f position = new Vector3f();
	    transform.get(position);
	    return position;
	}

	public float getWidth() {
	    return 1f; 
	}

	public float getHeight() {
	    return 1f; 
	}

	public float getLength() {
	    return 1f; 
	}
	
}






