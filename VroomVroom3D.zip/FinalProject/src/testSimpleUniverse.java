import java.awt.GraphicsConfiguration;
import javax.swing.JFrame;
import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.geometry.ColorCube;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.vecmath.*;

public class testSimpleUniverse {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Simple Universe Test");
        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
        Canvas3D canvas3D = new Canvas3D(config);
        frame.add(canvas3D);
        frame.setVisible(true);
        SimpleUniverse universe = new SimpleUniverse(canvas3D);
        BranchGroup scene = createSceneGraph();
        scene.compile();
        universe.addBranchGraph(scene);
        universe.getViewingPlatform().setNominalViewingTransform();
    }

    private static BranchGroup createSceneGraph() {
        BranchGroup root = new BranchGroup();
        TransformGroup transformGroup = new TransformGroup();
        transformGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        transformGroup.addChild(new ColorCube(0.4));
        root.addChild(transformGroup);
        Alpha rotationAlpha = new Alpha(-1, 8000);
        RotationInterpolator rotator = new RotationInterpolator(rotationAlpha, transformGroup, new Transform3D(), 0.0f, (float) Math.PI * 2);
        rotator.setSchedulingBounds(new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0));
        root.addChild(rotator);
        AmbientLight ambientLight = new AmbientLight(new Color3f(1.0f, 1.0f, 1.0f));
        ambientLight.setInfluencingBounds(new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0));
        root.addChild(ambientLight);
        return root;
    }
}
