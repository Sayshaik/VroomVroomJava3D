import org.jogamp.java3d.Background;
import org.jogamp.java3d.BoundingSphere;
import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.Canvas3D;
import org.jogamp.java3d.DirectionalLight;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.vecmath.Color3f;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;


import java.awt.*;

import javax.swing.JFrame;

import javax.swing.*;

public class PowerUpTest {

    public static void main(String[] args) {
        // Set up the canvas for the 3D display
        Canvas3D canvas = new Canvas3D(SimpleUniverse.getPreferredConfiguration());

        // Create the universe and add the canvas to it
        SimpleUniverse universe = new SimpleUniverse(canvas);

        // Create the root of the scene graph
        BranchGroup root = new BranchGroup();

        // Create a new PowerUp instance and add it to the scene
        powerUp powerUp = new powerUp();
        Color3f powerUpColor = new Color3f(1.0f, 0.0f, 0.0f); // Red color
        double radius = 0.02;

        // Create a new TransformGroup for each PowerUp
        TransformGroup powerUpTG = powerUp.createCompletePowerUp(radius, powerUpColor);

        // Add the TransformGroup of PowerUp to the root node
        root.addChild(powerUpTG);

        // Set up a background color
        Background background = new Background(new Color3f(0.5f, 0.5f, 0.5f));  // Light grey
        background.setApplicationBounds(new BoundingSphere(new Point3d(), 100.0));
        root.addChild(background);

        // Set up a light source
        DirectionalLight light = new DirectionalLight(new Color3f(1.0f, 1.0f, 1.0f), new Vector3f(0.0f, -1.0f, -1.0f));
        light.setInfluencingBounds(new BoundingSphere(new Point3d(), 100.0));
        root.addChild(light);

        // Create a simple view platform
        universe.getViewingPlatform().setNominalViewingTransform();

        // Add the scene graph to the universe
        universe.addBranchGraph(root);

        // Create a simple frame to contain the canvas
        JFrame frame = new JFrame("PowerUp Test");
        frame.getContentPane().add(canvas);
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Rotate the object over time (animation logic)
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(100);  // Update every 100ms
                    powerUp.alpha += 0.01f;
                    if (powerUp.alpha >= 1.0f || powerUp.alpha <= 0.0f) {
                        powerUp.alphaIncrement *= -1;
                    }
                    powerUp.update();  // Update the geometry of the power-up
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}