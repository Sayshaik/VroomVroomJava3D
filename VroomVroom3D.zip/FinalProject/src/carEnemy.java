import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;


import org.jogamp.java3d.utils.geometry.Box;

public class carEnemy {
    private static final float START_Z = -250.0f;

    private float speed;
    private TransformGroup tg;
    private Vector3f position;
    private BranchGroup wrapper;
    private Box shape;
    
    private Shape3D ballShape;
    private Appearance ballAppearance;
    private BowlingBall bowlingBall;


    public carEnemy(int lane, Color3f color, float speed) {
        this.speed = speed;
        this.position = new Vector3f(lane, 1.0f, START_Z);
        this.ballAppearance = createCarAppearance();
        // Set up transform group
        tg = new TransformGroup();
        tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        tg.setCapability(TransformGroup.ALLOW_CHILDREN_EXTEND);
        tg.setCapability(TransformGroup.ALLOW_CHILDREN_WRITE);
        tg.setTransform(new Transform3D());
      

        
        bowlingBall = new BowlingBall();
        TransformGroup ballTG = bowlingBall.position_Object();
        Transform3D ballTransform = new Transform3D();
        ballTransform.setTranslation(new Vector3f(0.0f, 0.5f, 1.0f)); // Adjust to position it above the car
        ballTG.setTransform(ballTransform);

        tg.addChild(ballTG);

        bowlingBall.setCapability(Shape3D.ALLOW_GEOMETRY_READ);
        bowlingBall.setCapability(Shape3D.ALLOW_BOUNDS_READ);
        bowlingBall.setCapability(Shape3D.ENABLE_COLLISION_REPORTING);

        bowlingBall.setCollisionBounds(new BoundingBox(
            new Point3d(-1, -1, -3),
            new Point3d(1, 1, 3)
        ));


        

        // Create wrapper branch group
        wrapper = new BranchGroup();
        wrapper.setCapability(BranchGroup.ALLOW_DETACH);
        wrapper.addChild(tg);

        updateTransform();
    }
    private Appearance createCarAppearance() {
        Appearance app = new Appearance();

        // Set material properties
        Material material = new Material();
        material.setDiffuseColor(new Color3f(0.8f, 0.0f, 0.0f)); // Red color
        material.setSpecularColor(new Color3f(0.4f, 0.4f, 0.4f));
        material.setShininess(32.0f);
        app.setMaterial(material);

        return app;
    }
    
    public void update(float travel_speed) {
        position.z += speed + travel_speed;
        updateTransform();
    }

    private void updateTransform() {
        Transform3D t3d = new Transform3D();
        t3d.setTranslation(position);
        tg.setTransform(t3d);
    }

    public boolean isOffscreen() {
        return position.z > 20;
    }

    public Node getNode() {
        return wrapper;
    }

    public TransformGroup getTransformGroup() {
        return tg;
    }

	
}