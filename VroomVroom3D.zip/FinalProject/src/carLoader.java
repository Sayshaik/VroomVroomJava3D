/*import java.io.FileNotFoundException;

import org.jogamp.java3d.*;
import org.jogamp.java3d.loaders.*;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.java3d.utils.geometry.Box;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.*;

public abstract class carLoader{
	protected Alpha rotationAlpha;                           // NOTE: keep for future use
    protected BranchGroup objBG;                             // load external object to 'objBG'
    protected TransformGroup objTG;                          // use 'objTG' to position an object
    protected TransformGroup objRG;                          // use 'objRG' to rotate an object
    protected double scale;                                  // use 'scale' to define scaling
    protected Vector3f post;    
    protected Shape3D obj_shape;// use 'post' to specify location
    
    //these abstract methods should be implemented by other classes
    public abstract TransformGroup position_Object();        // need to be defined in derived classes
    public abstract void add_Child(TransformGroup nextTG);
    
    protected void setAlpha(Alpha alpha) {
        this.rotationAlpha = alpha;   
}
    public Alpha get_Alpha() {
        return rotationAlpha;
    } 
    //loads and returns object shape from file 
    private Scene loadShape(String obj_name) {
        ObjectFile f = new ObjectFile(ObjectFile.RESIZE, (float) (60 * Math.PI / 180.0));
        Scene s = null;
        try {                                                // load object's definition file to 's'
            s = f.load("models/" + obj_name + ".obj");
        } catch (FileNotFoundException e) {
            System.err.println(e);
            System.exit(1);
        } catch (ParsingErrorException e) {
            System.err.println(e);
            System.exit(1);
        } catch (IncorrectFormatException e) {
            System.err.println(e);
            System.exit(1);
        }
        return s;                                            // return the object shape in 's'
    }
    
    protected void transform_Object(String obj_name) {
        Transform3D scaler = new Transform3D();
        scaler.setScale(scale);                              // set scale for the 4x4 matrix
        scaler.setTranslation(post);                         // set translations for the 4x4 matrix
        objTG = new TransformGroup(scaler);                  // set the translation BG with the 4x4 matrix
        objBG = loadShape(obj_name).getSceneGroup();         // load external object to 'objBG'
        obj_shape = (Shape3D) objBG.getChild(0);             // get and cast the object to 'obj_shape'
        obj_shape.setName(obj_name);                         // use the name to identify the object
    }
    
    //change this later
    protected Appearance app = new Appearance();
    protected int shine = 32;                                // shininess level adjuster
    protected Color3f[] mtl_clr = {
            new Color3f(1.000000f, 1.000000f, 1.000000f), //white (ambient color)
            new Color3f(0.772500f, 0.654900f, 0.000000f), //gold like color (diffuse color)
            new Color3f(0.175000f, 0.175000f, 0.175000f), //dark grey (specular color)
            new Color3f(0.000000f, 0.000000f, 0.000000f) //black (emissive color)
    };
    
    protected void obj_Appearance() {
        Material mtl = new Material();                       // create new material instance
        mtl.setShininess(shine);		//sets the material shininess level
        mtl.setAmbientColor(mtl_clr[0]);                //sets ambient color
        mtl.setDiffuseColor(mtl_clr[1]); 			//sets diffuse color
        mtl.setSpecularColor(mtl_clr[2]);			//sets specular color
        mtl.setEmissiveColor(mtl_clr[3]);                    //set emissive color for glowiness
        mtl.setLightingEnable(true);		//this enables lighiting effects

        app.setMaterial(mtl);                                // set appearance's material
        obj_shape.setAppearance(app);                        // set object's appearance
    }
    
}

class BowlingBall extends carLoader{
	public BowlingBall() {
		scale = 1.0;                                         // scale the object
        post = new Vector3f(0f, 0f, 0f);                     // position it at origin
        transform_Object("bowlingBall");                      // load the bowling ball model (make sure the model is in the correct directory)
        obj_Appearance(); 
		
	}


public TransformGroup position_Object() {
	Transform3D rotateAxis = new Transform3D();
    rotateAxis.rotY(0.01);  // adjust speed of rotation (0.01 radians per frame)
    objRG = new TransformGroup(rotateAxis);
    objRG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);  // allow the transformation to be updated
    objTG.addChild(objRG);
    objRG.addChild(objBG);

    // Create rotation using Alpha to manage smooth continuous animation
    rotationAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE | Alpha.DECREASING_ENABLE, 0, 0, 5000, 5000, 200, 5000, 5000, shine);
    RotationInterpolator rotationInterpolator = new RotationInterpolator(rotationAlpha, objRG);
    rotationInterpolator.setSchedulingBounds(new BoundingSphere(new Point3d(), 1000.0)); // define a bounding sphere for animation scheduling
    objRG.addChild(rotationInterpolator);

    return objTG;
}
public void add_Child(TransformGroup nextTG) {
    objRG.addChild(nextTG);                              // attach the next transformGroup to 'objTG'
}
}*/
