import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Stopwatch class implements ActionListener to handle button clicks
public class Stopwatch implements ActionListener {

    JLabel timeLabel = new JLabel(); // Label to display the time

    // Time tracking variables (in milliseconds)
    int elapsedTime = 0;
    int seconds = 0;
    int minutes = 0;
    boolean started = false; // To track whether the stopwatch is running
    boolean collision = false; // Collision flag to stop the stopwatch

    // Strings to display time in "MM:SS" format
    String seconds_string = String.format("%02d", seconds);
    String minutes_string = String.format("%02d", minutes);

    // Timer object to update the time every 1000 ms (1 second)
    Timer timer = new Timer(1000, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (collision) {
                stop();
                return;
            }

            elapsedTime += 1000; // Increment elapsed time by 1 second

            // Calculate minutes and seconds from elapsed time
            minutes = (elapsedTime / 60000) % 60;
            seconds = (elapsedTime / 1000) % 60;

            // Update time strings to maintain "00" format
            seconds_string = String.format("%02d", seconds);
            minutes_string = String.format("%02d", minutes);

            // Update the time display
            timeLabel.setText(minutes_string + ":" + seconds_string);
        }
    });

    // Play button with a play symbol
    JButton playButton = new JButton("▶");

    // Constructor to set up the stopwatch UI
    Stopwatch(JPanel panel) {
        // Initial time display
        timeLabel.setText(minutes_string + ":" + seconds_string);
        timeLabel.setBounds(100, 100, 200, 100); // Position and size of time label
        timeLabel.setFont(new Font("Serif", Font.BOLD, 35)); // Font styling
        timeLabel.setOpaque(false); // Enable background color
        timeLabel.setHorizontalAlignment(JTextField.NORTH_EAST); // Center text alignment

        timeLabel.setBorder(null);
        int width = 100;
        int height = 30;
        int xPos = panel.getWidth() - width - 20; //20px from the right d
        int yPos = 20;
        
        timeLabel.setBounds(xPos, yPos, width, height);
        // Configure play button
        playButton.setBounds(150, 250, 100, 50);
        playButton.setFont(new Font("Ink Free", Font.PLAIN, 30));
        playButton.setFocusable(false); // Remove focus border
        playButton.addActionListener(this); // Attach event listener

        // Create and configure frame
        JFrame frame = new JFrame();
        panel.add(playButton);
        panel.add(timeLabel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close on exit
        panel.setSize(420, 420); // Frame size
        panel.setLayout(null); // Disable default layout manager
        frame.setVisible(true); // Make the frame visible
    }

    // Handle play button click
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == playButton) {
            if (!started) {
                started = true;
                collision = false; // Reset collision flag
                elapsedTime = 0; // Reset timer
                playButton.setText("▶"); // Ensure button stays play
                start();
            }
        }
    }
    public boolean isRunning() {
        return started;
    }

    // Start the timer
    void start() {
        timer.start();
    }

    // Stop the timer
    void stop() {
        timer.stop();
        started = false;
    }
    public void updatePosition(JPanel panel) {
    	int width = 100;
    	int height = 30;
    	int xPos = panel.getWidth() - width - 20;
    	
    	timeLabel.setBounds(xPos, 20, width, height);
    	
    }

}