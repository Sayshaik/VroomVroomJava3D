import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.vecmath.*;
 

import javax.sound.sampled.Clip;


import org.jogamp.java3d.utils.geometry.Box;
import org.jogamp.java3d.utils.geometry.Primitive;
import org.jogamp.java3d.utils.image.TextureLoader;


public class road extends JPanel implements ActionListener, KeyListener {
  
	private static Car3D playerCar;
	private static final long serialVersionUID = 1L;
    private static JFrame frame;
    private static String frame_name = "Road Demo";
    private static road instance;
    private Clip backgroundMusic;

    private static float road_seg = 130f;
    private static final float SEGMENT_LENGTH = road_seg * 2;
    private static final float SPAWN_Z = -road_seg;
    private static final float WRAP_THRESHOLD = road_seg;
    private static final float OVERLAP_Z = 5f;

    private static TransformGroup road1TG, road2TG, road3TG;
    private static TransformGroup grass1LTG, grass1RTG, grass2LTG, grass2RTG, grass3LTG, grass3RTG;
    
    private static TransformGroup carTG;
    private static final int[] lanes = {-2, 0, 2};
    private static int currentLaneIndex = 1;

    private static Vector3f roadPosition1 = new Vector3f(0.0f, 0.0f, SPAWN_Z);
    private static Vector3f roadPosition2 = new Vector3f(0.0f, 0.0f, SPAWN_Z + SEGMENT_LENGTH);
    private static Vector3f roadPosition3 = new Vector3f(0.0f, 0.0f, SPAWN_Z + SEGMENT_LENGTH * 2);

    private static float speed = 0f;
    private static final float ACCELERATION = 0.1f;
    private static final float BRAKE_DECELERATION = 0.3f;
    private static final float COAST_DECELERATION = 0.02f;
    private static  float MAX_SPEED = 5f;

    private static boolean accelerating = false;
    private static boolean braking = false;
    private Timer timer;

    private List<carEnemy> enemies = new ArrayList<>();
    private static BranchGroup sceneRoot;
    private static BranchGroup dynamicGroup;
    private randomizer rand = new randomizer();

    private HUD hud;

    private int score = 0;
    private int clock = 0;
    private Timer secondTimer;
    
    private static SoundUtilityJOAL soundJOAL;
    private List<BranchGroup> powerUps = new ArrayList<>();
    private static final float POWER_UP_SPAWN_CHANCE = 0.005f;
    private static final float POWER_UP_Y_OFFSET = 2f;
	private static final int BOOST_DURATION = 5000;
	

    private static BranchGroup create_Scene() {
    	sceneRoot = new BranchGroup();
        sceneRoot.setCapability(Group.ALLOW_CHILDREN_EXTEND);
        sceneRoot.setCapability(Group.ALLOW_CHILDREN_WRITE);
        sceneRoot.setCapability(Group.ALLOW_CHILDREN_READ);
 
        addSunlight(sceneRoot);
        
        dynamicGroup = new BranchGroup();
        dynamicGroup.setCapability(Group.ALLOW_CHILDREN_EXTEND);
        dynamicGroup.setCapability(Group.ALLOW_CHILDREN_WRITE);
        dynamicGroup.setCapability(Group.ALLOW_CHILDREN_READ);

        road1TG = createTransformGroup();
        road2TG = createTransformGroup();
        road3TG = createTransformGroup();

        grass1LTG = createTransformGroup(); grass1RTG = createTransformGroup();
        grass2LTG = createTransformGroup(); grass2RTG = createTransformGroup();
        grass3LTG = createTransformGroup(); grass3RTG = createTransformGroup();

        Appearance roadTexture = texturedAppearance("road_texture.jpg");
        road1TG.addChild(new Box(3, 0.01f, road_seg, Primitive.GENERATE_TEXTURE_COORDS, roadTexture));
        road2TG.addChild(new Box(3, 0.01f, road_seg, Primitive.GENERATE_TEXTURE_COORDS, roadTexture));
        road3TG.addChild(new Box(3, 0.01f, road_seg, Primitive.GENERATE_TEXTURE_COORDS, roadTexture));

        Appearance grassTexture = texturedAppearance("grass.jpg");
        grass1LTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));
        grass1RTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));
        grass2LTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));
        grass2RTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));
        grass3LTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));
        grass3RTG.addChild(new Box(70, 0.01f, road_seg + OVERLAP_Z, Primitive.GENERATE_TEXTURE_COORDS, grassTexture));

        Car3D playerCar = new Car3D();  // Bounds are set automatically in constructor
        carTG = playerCar.getCarTG();
        carTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);


  

        updateCarLane(); 
        updateTransforms();
        sceneRoot.addChild(road1TG); sceneRoot.addChild(grass1LTG); sceneRoot.addChild(grass1RTG);
        sceneRoot.addChild(road2TG); sceneRoot.addChild(grass2LTG); sceneRoot.addChild(grass2RTG);
        sceneRoot.addChild(road3TG); sceneRoot.addChild(grass3LTG); sceneRoot.addChild(grass3RTG);
        sceneRoot.addChild(carTG);
        sceneRoot.addChild(dynamicGroup);
        
        TextureLoader texLoader = new TextureLoader("images/backgroundSky.jpg", null);
        Background background = new Background();
        background.setImage(texLoader.getImage());
        background.setImageScaleMode(Background.SCALE_FIT_ALL);
        background.setApplicationBounds(new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 100.0));
        sceneRoot.addChild(background);

        return sceneRoot;
    }
    private void spawnPowerUp() {
        boolean spawnLeft = rand.nextBoolean();
        int roadSegment = rand.nextInt(3) + 1;
        float randomZ = -3 + (float) Math.random() * (700 - (-3));
        Vector3f basePosition = new Vector3f(0.0f, 0.0f, randomZ);

        // Select the road segment where the power-up will appear
        switch (roadSegment) {
            case 1: basePosition = roadPosition1; break;
            case 2: basePosition = roadPosition2; break;
            default: basePosition = roadPosition3; break;
        }

        // Define horizontal offset (left or right of the road)
        float xOffset = spawnLeft ? -13f : 13f;

        // Create a new powerUp object using your custom powerUp class
        powerUp newPowerUp = new powerUp();
        
        // Create the complete power-up (returns TransformGroup with geometry)
        TransformGroup powerUpTG = newPowerUp.createCompletePowerUp(1.0, new Color3f(1.0f, 0.0f, 1.0f));  // Adjust radius and color as needed

        // Set the position for the power-up in world space
        Transform3D transform = new Transform3D();
        transform.setTranslation(new Vector3f(xOffset, POWER_UP_Y_OFFSET, basePosition.z));
        powerUpTG.setTransform(transform);
        powerUpTG.setCapability(TransformGroup.ALLOW_PICKABLE_READ);
        powerUpTG.setCapability(TransformGroup.ALLOW_PICKABLE_WRITE);
        powerUpTG.setCapability(TransformGroup.ALLOW_CHILDREN_READ);

        // Attach user data to the TransformGroup to allow identification later
        powerUpTG.setUserData("PowerUp");  // Correct placement for user data

        // Create a container BranchGroup for the power-up
        BranchGroup powerUpBG = new BranchGroup();
        powerUpBG.setCapability(BranchGroup.ALLOW_DETACH);  // Allow this power-up to be removed later
        powerUpBG.addChild(powerUpTG);

        // Add the power-up to the dynamic group and the active power-ups list
        dynamicGroup.addChild(powerUpBG);
        powerUps.add(powerUpBG);
        powerUps.add(powerUpBG);
}




private void updatePowerUps() {
    if (Math.random() < POWER_UP_SPAWN_CHANCE && powerUps.size() < 3) {
        spawnPowerUp();
    }
    for (int i = powerUps.size() - 1; i >= 0; i--) {
        BranchGroup powerUpBG = powerUps.get(i);
        TransformGroup powerUpTG = (TransformGroup) powerUpBG.getChild(0);
        Transform3D transform = new Transform3D();
        powerUpTG.getTransform(transform);
        Vector3f position = new Vector3f();
        transform.get(position);
        position.z += speed;
        transform.setTranslation(position);
        powerUpTG.setTransform(transform);

        // Retrieve the powerUp object from the BranchGroup's user data
        powerUp newPowerUp = (powerUp) powerUpBG.getUserData();  // Retrieve the powerUp instance

        if (newPowerUp != null) {
            newPowerUp.update();  // Only call update if newPowerUp is not null
        }

        // Remove the power-up if it's out of view
        if (position.z > 10) {
            dynamicGroup.removeChild(powerUpBG);
            powerUps.remove(i);
        }
    }
}


    private static TransformGroup createTransformGroup() {
        TransformGroup tg = new TransformGroup();
        tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        return tg;
    }

    private static void updateTransforms() {
        road1TG.setTransform(vectorToTransform(roadPosition1));
        road2TG.setTransform(vectorToTransform(roadPosition2));
        road3TG.setTransform(vectorToTransform(roadPosition3));

        Vector3f left = new Vector3f(-73f, 0.0f, 0.0f);
        Vector3f right = new Vector3f(73f, 0.0f, 0.0f);

        grass1LTG.setTransform(vectorToTransform(addVectors(roadPosition1, left)));
        grass1RTG.setTransform(vectorToTransform(addVectors(roadPosition1, right)));
        grass2LTG.setTransform(vectorToTransform(addVectors(roadPosition2, left)));
        grass2RTG.setTransform(vectorToTransform(addVectors(roadPosition2, right)));
        grass3LTG.setTransform(vectorToTransform(addVectors(roadPosition3, left)));
        grass3RTG.setTransform(vectorToTransform(addVectors(roadPosition3, right)));
    }

    private static Transform3D vectorToTransform(Vector3f vec) {
        Transform3D t = new Transform3D();
        t.setTranslation(vec);
        return t;
    }

    private static Vector3f addVectors(Vector3f v1, Vector3f v2) {
        Vector3f result = new Vector3f();
        result.add(v1, v2);
        return result;
    }

    private static void updateCarLane() {
        Transform3D carTransform = new Transform3D();
        carTransform.setTranslation(new Vector3f(lanes[currentLaneIndex], 1.0f, -3.0f));
        carTG.setTransform(carTransform);
        
        Transform3D rotation = new Transform3D();
        rotation.rotY(Math.PI);
        carTransform.mul(rotation);
        carTG.setTransform(carTransform);
    }

    public road(BranchGroup scene) throws Throwable {
        
    	instance = this;
        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
        Canvas3D canvas3D = new Canvas3D(config);
        canvas3D.setSize(1000, 800);
        
        mousepick picker = new mousepick(sceneRoot);
        canvas3D.addMouseListener(picker);
        
        canvas3D.addKeyListener(this);
        canvas3D.setFocusable(true);
        canvas3D.requestFocus();

        SimpleUniverse su = new SimpleUniverse(canvas3D);
        Commons.define_Viewer(su, new Point3d(0, 1.0, 10.0));
        View view = su.getViewer().getView();
        view.setBackClipDistance(40.0);
        view.setFrontClipDistance(0.1);

        TransformGroup vpTG = su.getViewingPlatform().getViewPlatformTransform();
        Transform3D rotateDown = new Transform3D(); rotateDown.rotX(-Math.toRadians(10));
        Transform3D translate = new Transform3D(); translate.setTranslation(new Vector3f(0, 2.0f, 10.0f));
        rotateDown.mul(translate); vpTG.setTransform(rotateDown);

        hud = new HUD();
        sceneRoot.addChild(hud.getScoreBranchGroup());
        sceneRoot.addChild(hud.getTimerBranchGroup());
        
        su.addBranchGraph(scene);
        setLayout(new BorderLayout()); add("Center", canvas3D); frame.setSize(1000, 800); frame.setVisible(true);

        timer = new Timer(16, e -> updateMovement());
        timer.start();
        
        secondTimer = new Timer(1000, e -> {
            clock++;
            hud.updateTime(clock);
            score = (int) (score + 1 * speed);
            hud.updateScore(score);
        });
        secondTimer.start();
        
        soundJOAL = new SoundUtilityJOAL();
        if (!soundJOAL.load("honk", 0f, 0f, 10f, false)) {
            System.out.println("Could not load honk.wav");
        }
        if (!soundJOAL.load("background", 0f, 0f, 10f, true)) {
            System.out.println("Could not load background.wav");
        } else {
            soundJOAL.play("background");
        }
        playBackgroundMusic("sounds/background.wav");
        
    }
    public static void speedBoost() {
        final float boostedMaxSpeed = MAX_SPEED * 2;

        MAX_SPEED = boostedMaxSpeed;

        Timer boostTimer = new Timer(BOOST_DURATION, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MAX_SPEED = 5f;
                System.out.println("speed avtice");
            }
        });
        boostTimer.setRepeats(false);
        boostTimer.start();
    }
    
    private void playBackgroundMusic(String filePath) throws Exception {
        try {
            File soundFile = new File(filePath);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundFile);
            backgroundMusic = AudioSystem.getClip();
            backgroundMusic.open(audioStream);
            backgroundMusic.loop(Clip.LOOP_CONTINUOUSLY);
            backgroundMusic.start();
        } catch (IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    private void updateMovement() {
        // Smooth acceleration and deceleration
        if (accelerating) speed = Math.min(speed + ACCELERATION, MAX_SPEED);
        else if (braking) speed = Math.max(speed - BRAKE_DECELERATION, 0);
        else speed = Math.max(speed - COAST_DECELERATION, 0);

        // Update all road positions together
        float minZ = Math.min(roadPosition1.z, Math.min(roadPosition2.z, roadPosition3.z));

        roadPosition1.z += speed;
        roadPosition2.z += speed;
        roadPosition3.z += speed;

        // Wrap road segments in sync to avoid staggered movement
        if (roadPosition1.z - road_seg >= WRAP_THRESHOLD) {
            roadPosition1.z = minZ - SEGMENT_LENGTH + OVERLAP_Z;
            updateGrassPosition(grass1LTG, grass1RTG, roadPosition1);
        }
        if (roadPosition2.z - road_seg >= WRAP_THRESHOLD) {
            roadPosition2.z = minZ - SEGMENT_LENGTH + OVERLAP_Z;
            updateGrassPosition(grass2LTG, grass2RTG, roadPosition2);
        }
        if (roadPosition3.z - road_seg >= WRAP_THRESHOLD) {
            roadPosition3.z = minZ - SEGMENT_LENGTH + OVERLAP_Z;
            updateGrassPosition(grass3LTG, grass3RTG, roadPosition3);
        }
    

        updateTransforms();

        if (rand.shouldSpawnCar() == 5) {
            int lane = rand.assignLane();
            Color3f color = rand.assignColor();
            float carSpeed = rand.assignSpeed();
            carEnemy enemy = new carEnemy(lane, color, carSpeed);
            enemies.add(enemy);
            dynamicGroup.addChild(enemy.getNode());
        }

        crashDetector.updateScore(score);
        
        for (int i = enemies.size() - 1; i >= 0; i--) {
            carEnemy enemy = enemies.get(i);
            enemy.update(speed);
            if (enemy.isOffscreen()) {
                dynamicGroup.removeChild(enemy.getNode());
                enemies.remove(i);
            }
            if (crashDetector.checkCollision(carTG, enemies)) {
                System.out.println("crash detected");
                timer.stop();
                secondTimer.stop();
            }
            updatePowerUps();
        }
    }

public static void main(String[] args) throws Throwable {
        frame = new JFrame(frame_name);
        BranchGroup scene = create_Scene();
        road r = new road(scene);
        frame.getContentPane().add(r);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        crashDetector.initialize(frame);
        
       
    }

    @Override public void keyPressed(KeyEvent e) {
    	if (e.getKeyCode() == KeyEvent.VK_SPACE) accelerating = true;
        if (e.getKeyCode() == KeyEvent.VK_SHIFT) braking = true;
        if (e.getKeyCode() == KeyEvent.VK_A && currentLaneIndex > 0) { 
            currentLaneIndex--; 
            updateCarLane(); 
        }
        if (e.getKeyCode() == KeyEvent.VK_D && currentLaneIndex < lanes.length - 1) { 
            currentLaneIndex++; 
            updateCarLane(); 
        }
        if (e.getKeyCode() == KeyEvent.VK_S) {
        	 soundJOAL.play("honk"); 
        	 System.out.println("honk");
        }
    }

    private static Appearance texturedAppearance(String textureFile) {
        Appearance appearance = new Appearance();
        
        TextureLoader loader = new TextureLoader(textureFile, null);
        Texture texture = loader.getTexture();
        
        if (texture == null) {
            System.out.println("Texture file not found: " + textureFile);
            return flatColorAppearance(new Color3f(1.0f, 1.0f, 1.0f)); // Default white if texture fails
        }

        texture.setBoundaryModeS(Texture.WRAP);
        texture.setBoundaryModeT(Texture.WRAP);
        texture.setMagFilter(Texture.BASE_LEVEL_LINEAR);

        TextureAttributes texAttr = new TextureAttributes();
        texAttr.setTextureMode(TextureAttributes.MODULATE);
        
        appearance.setTexture(texture);
        appearance.setTextureAttributes(texAttr);
        
        Material material = new Material();
       material.setDiffuseColor(new Color3f(1.0f, 1.0f, 1.0f));
        appearance.setMaterial(material);
        return appearance;
    }
    @Override 
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) accelerating = false;
        if (e.getKeyCode() == KeyEvent.VK_SHIFT) braking = false;
    }

    @Override public void keyTyped(KeyEvent e) {}
    @Override public void actionPerformed(ActionEvent e) {}

    /*private static Appearance flatColorAppearance(Color3f color) {
        Appearance appearance = new Appearance();
        appearance.setColoringAttributes(new ColoringAttributes(color, ColoringAttributes.NICEST));
        return appearance;
    }*/
    
    
    private static Appearance flatColorAppearance(Color3f color) {
        Appearance appearance = new Appearance();
        Material material = new Material();
        material.setDiffuseColor(color);           // The color you want for the object
        material.setSpecularColor(new Color3f(0.8f, 0.8f, 0.8f)); // White specular to simulate shine (optional)
        material.setAmbientColor(color);           // Set ambient color to be the same as the diffuse color
        material.setEmissiveColor(new Color3f(0.0f, 0.0f, 0.0f)); // No emissive color
        material.setLightingEnable(true);         // Enable lighting for this material
        appearance.setMaterial(material);
        return appearance;
    }
    
    
    private static void addSunlight(BranchGroup root) {
    	Color3f lightColor = new Color3f(1.2f, 1.2f, 1.0f);
        Vector3f lightDirection = new Vector3f(1.0f, -1.0f, -0.5f);
        lightDirection.normalize();
        DirectionalLight sunLight = new DirectionalLight(lightColor, lightDirection);
        BoundingSphere bounds = new BoundingSphere(new Point3d(0.0, 0.0, 0.0), 1000.0);
        sunLight.setInfluencingBounds(bounds);
        root.addChild(sunLight);
    }
    

    
    private static void updateGrassPosition(TransformGroup leftTG, TransformGroup rightTG, Vector3f roadPosition) {
    	Transform3D leftTransform = new Transform3D();
        leftTransform.setTranslation(new Vector3f(-73f, 0f, roadPosition.z));
        leftTG.setTransform(leftTransform);
        Transform3D rightTransform = new Transform3D();
        rightTransform.setTranslation(new Vector3f(73f, 0f, roadPosition.z));
        rightTG.setTransform(rightTransform);
    }
    

    
    public static road getInstance() {
        return instance;
    }

    public void resetGame() {
        speed = 0f;
        clock = 0;
        score = 0;
        currentLaneIndex = 1;
        updateCarLane();
        //here we reset the game after it crashes
        // Clear enemies
        for (carEnemy enemy : enemies) {
            dynamicGroup.removeChild(enemy.getNode());
        }
        enemies.clear();
        hud.updateScore(0);
        hud.updateTime(0);
        
        if (!timer.isRunning()) timer.start();
        if (!secondTimer.isRunning()) secondTimer.start();
    }
    
}