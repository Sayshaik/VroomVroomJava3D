import java.util.Random;
import org.jogamp.vecmath.Color3f;

public class randomizer {
    private static final int[] LANES = {-2, 0, 2};
    private static final Color3f[] color_options = {Commons.White};
    private Random r;

    public randomizer() {
        r = new Random();
    }

    public int assignLane() {
        return LANES[r.nextInt(LANES.length)];
    }

    public Color3f assignColor() {
        return color_options[r.nextInt(color_options.length)];
    }

    public int shouldSpawnCar() {
        return r.nextInt(50) + 1;
    }

    public float assignSpeed() {
        return 1.0f + r.nextFloat() * 2.0f;
    }

    public boolean nextBoolean() {
        return r.nextBoolean();
    }

    public int nextInt(int bound) {
        return r.nextInt(bound);
    }

    public float nextFloat(int bound) {
        return r.nextFloat(bound);
    }
}